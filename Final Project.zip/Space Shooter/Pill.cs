﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Shooter
{
    // This class creates the pill animation and actions
    class Pill
    {
        PictureBox pillSpawn = new PictureBox();

        bool pillExist;

        int pillPostLeft;
        int pillPosTop;

        public PictureBox PillSpawn { get => pillSpawn; set => pillSpawn = value; }
        public bool PillExist { get => pillExist; set => pillExist = value; }
        public int PillPosLeft { get => pillPostLeft; set => pillPostLeft = value; }
        public int PillPosTop { get => pillPosTop; set => pillPosTop = value; }

        public void SpawnPill(Form form)
        {
            PillSpawn.Image = Properties.Resources.Pill;
            PillSpawn.SizeMode = PictureBoxSizeMode.AutoSize;
            PillSpawn.Tag = "pill";
            PillSpawn.Left = PillPosLeft;
            PillSpawn.Top = PillPosTop;

            form.Controls.Add(PillSpawn);
            PillSpawn.BringToFront();
        }
    }
}
