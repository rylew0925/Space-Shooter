﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Shooter
{
    public partial class SpaceShooter : Form
    {
        SpawnManager spawnManage;
        CollisionManager collisionManage;
        EnemyMovement movementManage;

        bool goLeft, goRight, goUp, goDown;

        int playerShield = 100;

        int speed = 10;

        int score = 0;

        Direction playerDirection;

        public SpawnManager SpawnManage { get => spawnManage; }
        public int PlayerShield { get => playerShield; set => playerShield = value; }

        public int Score { get => score; set => score = value; }
        public SpaceShooter()
        {
            spawnManage = new SpawnManager(this);
            collisionManage = new CollisionManager(this);
            movementManage = new EnemyMovement(this);
            InitializeComponent();
        }

        private void GameTick(object sender, EventArgs e)
        {
            player.BringToFront();

            IsPlayerAlive();

            labelScore.Text = "Score: " + Score;

            MovePlayer();

            collisionManage.DetectCollision();

            movementManage.MoveUFO();
        }

        // Controls the movement of the player's ship using keyboard controls
        private void MovePlayer()
        {
            // Sets up the control for the Left arrow key on the keyboard            
            if (goLeft == true && player.Left > 0)
            {
                player.Left -= speed;
            }
            // Sets up the control for the Right arrow key on the keyboard
            if (goRight == true && player.Left + player.Width < this.ClientSize.Width)
            {
                player.Left += speed;
            }
            // Sets up the control for the Up arrow key on the keyboard
            if (goUp == true && player.Top > 0)
            {
                player.Top -= speed;
            }
            // Sets up the control for the Down arrow key on the keyboard
            if (goDown == true && player.Top + player.Height < this.ClientSize.Height - 100)
            {
                player.Top += speed;
            }
        }

        // Verifies if the player's shields or health is still up and continues the game or else ends the game if the player's shields or health are depleted
        private void IsPlayerAlive()
        {
            // The player's ship is still alive
            if (PlayerShield > 1)
            {
                shieldsBar.Value = PlayerShield;
            }
            // The player's ship has been destroyed
            else
            {
                gameTimer.Stop();
                GameOver gameOver = new GameOver(score);
                gameOver.ShowDialog();
                this.Close();
            }
        }

        // If the player pressed any of the arrow keys or the space bar on the keyboard, then the player's ship's icon faces Up, Down, Left, or Right or fires its weapons
        private void IsKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = true;
                playerDirection = Direction.left;
                player.Image = Properties.Resources.Left;
            }

            if (e.KeyCode == Keys.Right)
            {
                goRight = true;
                playerDirection = Direction.right;
                player.Image = Properties.Resources.Right;
            }

            if (e.KeyCode == Keys.Up)
            {
                goUp = true;
                playerDirection = Direction.up;
                player.Image = Properties.Resources.Up;
            }

            if (e.KeyCode == Keys.Down)
            {
                goDown = true;
                playerDirection = Direction.down;
                player.Image = Properties.Resources.Down;
            }
        }

        // If the player did not press any of the arrow keys or the space bar on the keyboard, then the player's ship's icon does not face Up, Down, Left, or Right and does not fire its weapons

        private void IsKeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }

            if (e.KeyCode == Keys.Right)
            {
                goRight = false;
            }

            if (e.KeyCode == Keys.Up)
            {
                goUp = false;
            }

            if (e.KeyCode == Keys.Down)
            {
                goDown = false;
            }

            if (e.KeyCode == Keys.Space)
            {
                ShootLazer(playerDirection);
            }
        }

        private void ShootLazer(Direction direction)
        {
            Lazer newLazer = new LazerBlue();

            newLazer.Direction = playerDirection;

            newLazer.LazerPosLeft = player.Left + (player.Width / 2);

            newLazer.LazerPosTop = player.Top + (player.Height / 2);

            newLazer.CreateLazer(this);
        }
    }
}
