﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Shooter
{
    // Creates big red lasers from the red UFOs
    class LaserRedBig : Lazer
    {
        public override void CreateLazer(Form form)
        {
            CurrentLazer.Image = Properties.Resources.laserRed08;            

            CurrentLazer.Tag = "enemyLazer";

            base.CreateLazer(form);
        }
    }
}
